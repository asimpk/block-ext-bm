(function(){"use strict";var o={};console.log("From Content Script")})();

//# sourceMappingURL=content.js.map